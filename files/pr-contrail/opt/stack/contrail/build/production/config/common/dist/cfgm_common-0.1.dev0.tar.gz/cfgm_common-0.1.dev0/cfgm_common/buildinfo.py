build_info = "{\"build-info\" : [{\"build-version\" : \"3.2.3.3\", \"build-time\" : \"2017-08-08 06:48:56.495944\", \"build-user\" : \"root\", \"build-hostname\" : \"pr-contrail\", ";
